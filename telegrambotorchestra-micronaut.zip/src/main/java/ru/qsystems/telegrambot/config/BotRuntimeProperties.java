package ru.qsystems.telegrambot.config;

import io.micronaut.context.annotation.ConfigurationProperties;

@ConfigurationProperties("bot.runtime")
public class BotRuntimeProperties {
    private String clientPathYaml = "client_path.yml";
    private String flowOrder = "ACTION_FIRST";
    private String serviceBlacklist = "Оплата услуг";
    private String visitCallTemplate = "🔔 {visitorName}, ваш талон {ticketId}! Подойдите к окну {servicePointName}.";
    private String branchVisitCallTemplatesJson = "";
    private boolean multiServiceEnabled = false;
    private String branchMultiServiceEnabledJson = "";

    public String getClientPathYaml() {
        return clientPathYaml;
    }

    public void setClientPathYaml(String clientPathYaml) {
        this.clientPathYaml = clientPathYaml;
    }

    public String getFlowOrder() {
        return flowOrder;
    }

    public void setFlowOrder(String flowOrder) {
        this.flowOrder = flowOrder;
    }

    public String getServiceBlacklist() {
        return serviceBlacklist;
    }

    public void setServiceBlacklist(String serviceBlacklist) {
        this.serviceBlacklist = serviceBlacklist;
    }

    public String getVisitCallTemplate() {
        return visitCallTemplate;
    }

    public void setVisitCallTemplate(String visitCallTemplate) {
        this.visitCallTemplate = visitCallTemplate;
    }

    public String getBranchVisitCallTemplatesJson() {
        return branchVisitCallTemplatesJson;
    }

    public void setBranchVisitCallTemplatesJson(String branchVisitCallTemplatesJson) {
        this.branchVisitCallTemplatesJson = branchVisitCallTemplatesJson;
    }

    public boolean isMultiServiceEnabled() {
        return multiServiceEnabled;
    }

    public void setMultiServiceEnabled(boolean multiServiceEnabled) {
        this.multiServiceEnabled = multiServiceEnabled;
    }

    public String getBranchMultiServiceEnabledJson() {
        return branchMultiServiceEnabledJson;
    }

    public void setBranchMultiServiceEnabledJson(String branchMultiServiceEnabledJson) {
        this.branchMultiServiceEnabledJson = branchMultiServiceEnabledJson;
    }
}
