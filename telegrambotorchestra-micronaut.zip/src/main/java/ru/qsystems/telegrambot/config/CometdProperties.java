package ru.qsystems.telegrambot.config;

import io.micronaut.context.annotation.ConfigurationProperties;

@ConfigurationProperties("bot.cometd")
public class CometdProperties {
    private boolean enabled = true;
    private String initChannel = "/events/INIT";
    private int connectTimeoutSeconds = 90;
    private int watchdogConnectTimeoutSeconds = 120;

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public String getInitChannel() { return initChannel; }
    public void setInitChannel(String initChannel) { this.initChannel = initChannel; }
    public int getConnectTimeoutSeconds() { return connectTimeoutSeconds; }
    public void setConnectTimeoutSeconds(int connectTimeoutSeconds) { this.connectTimeoutSeconds = connectTimeoutSeconds; }
    public int getWatchdogConnectTimeoutSeconds() { return watchdogConnectTimeoutSeconds; }
    public void setWatchdogConnectTimeoutSeconds(int watchdogConnectTimeoutSeconds) { this.watchdogConnectTimeoutSeconds = watchdogConnectTimeoutSeconds; }
}
