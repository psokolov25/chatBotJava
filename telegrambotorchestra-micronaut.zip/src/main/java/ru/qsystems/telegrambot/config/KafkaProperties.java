package ru.qsystems.telegrambot.config;

import io.micronaut.context.annotation.ConfigurationProperties;

@ConfigurationProperties("bot.kafka")
public class KafkaProperties {
    private boolean enabled = true;
    private String topic = "events";
    private String groupId = "telegram-queue-bot";
    private String bootstrapServers = "192.168.8.40:29092";
    private String branchBootstrapServersJson = "";

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public String getTopic() { return topic; }
    public void setTopic(String topic) { this.topic = topic; }
    public String getGroupId() { return groupId; }
    public void setGroupId(String groupId) { this.groupId = groupId; }
    public String getBootstrapServers() { return bootstrapServers; }
    public void setBootstrapServers(String bootstrapServers) { this.bootstrapServers = bootstrapServers; }
    public String getBranchBootstrapServersJson() { return branchBootstrapServersJson; }
    public void setBranchBootstrapServersJson(String branchBootstrapServersJson) { this.branchBootstrapServersJson = branchBootstrapServersJson; }
}
