package ru.qsystems.telegrambot.config;

import io.micronaut.context.annotation.ConfigurationProperties;

@ConfigurationProperties("bot.telegram")
public class TelegramProperties {
    private String token = "";
    private String apiUrl = "https://api.telegram.org";
    private boolean pollingEnabled = true;
    private int pollingTimeoutSeconds = 30;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getApiUrl() {
        return apiUrl;
    }

    public void setApiUrl(String apiUrl) {
        this.apiUrl = apiUrl;
    }

    public boolean isPollingEnabled() {
        return pollingEnabled;
    }

    public void setPollingEnabled(boolean pollingEnabled) {
        this.pollingEnabled = pollingEnabled;
    }

    public int getPollingTimeoutSeconds() {
        return pollingTimeoutSeconds;
    }

    public void setPollingTimeoutSeconds(int pollingTimeoutSeconds) {
        this.pollingTimeoutSeconds = pollingTimeoutSeconds;
    }

    public boolean hasToken() {
        return token != null && !token.isBlank();
    }
}
