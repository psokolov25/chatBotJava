package ru.qsystems.telegrambot.config;

import io.micronaut.context.annotation.ConfigurationProperties;

@ConfigurationProperties("bot.queue")
public class QueueProperties {
    private String system = "orchestra";
    private String orchestraUrl = "http://127.0.0.1:8080/";
    private String orchestraLogin = "superadmin";
    private String orchestraPassword = "";
    private String axiomaUrl = "http://127.0.0.1:8080/";
    private String axiomaLogin = "superadmin";
    private String axiomaPassword = "";
    private String branchId = "6";
    private String branchName = "Основное отделение";
    private String branchCode = "NTR";
    private String entryPointId = "2";
    private String branchesJson = "";

    public String getSystem() { return system; }
    public void setSystem(String system) { this.system = system; }
    public String getOrchestraUrl() { return orchestraUrl; }
    public void setOrchestraUrl(String orchestraUrl) { this.orchestraUrl = orchestraUrl; }
    public String getOrchestraLogin() { return orchestraLogin; }
    public void setOrchestraLogin(String orchestraLogin) { this.orchestraLogin = orchestraLogin; }
    public String getOrchestraPassword() { return orchestraPassword; }
    public void setOrchestraPassword(String orchestraPassword) { this.orchestraPassword = orchestraPassword; }
    public String getAxiomaUrl() { return axiomaUrl; }
    public void setAxiomaUrl(String axiomaUrl) { this.axiomaUrl = axiomaUrl; }
    public String getAxiomaLogin() { return axiomaLogin; }
    public void setAxiomaLogin(String axiomaLogin) { this.axiomaLogin = axiomaLogin; }
    public String getAxiomaPassword() { return axiomaPassword; }
    public void setAxiomaPassword(String axiomaPassword) { this.axiomaPassword = axiomaPassword; }
    public String getBranchId() { return branchId; }
    public void setBranchId(String branchId) { this.branchId = branchId; }
    public String getBranchName() { return branchName; }
    public void setBranchName(String branchName) { this.branchName = branchName; }
    public String getBranchCode() { return branchCode; }
    public void setBranchCode(String branchCode) { this.branchCode = branchCode; }
    public String getEntryPointId() { return entryPointId; }
    public void setEntryPointId(String entryPointId) { this.entryPointId = entryPointId; }
    public String getBranchesJson() { return branchesJson; }
    public void setBranchesJson(String branchesJson) { this.branchesJson = branchesJson; }
}
